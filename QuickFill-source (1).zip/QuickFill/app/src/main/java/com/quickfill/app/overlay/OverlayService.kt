package com.quickfill.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.quickfill.app.MainActivity
import com.quickfill.app.R
import com.quickfill.app.accessibility.AutofillAccessibilityService
import com.quickfill.app.data.PresetRepository
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var repository: PresetRepository
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var panelVisible = false
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        repository = PresetRepository(this)
        startForegroundWithNotification()
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        removePanel()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
    }

    private fun startForegroundWithNotification() {
        val channelId = "quickfill_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "QuickFill Bubble", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("QuickFill is running")
            .setContentText("Tap the floating bubble to autofill forms")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notification)
    }

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val bubble = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = bubble

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300
        bubbleParams = params

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) isDragging = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    runCatching { windowManager.updateViewLayout(bubble, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) togglePanel()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubble, params)
    }

    private fun togglePanel() {
        if (panelVisible) removePanel() else showPanel()
    }

    private fun showPanel() {
        val profile = repository.getActiveProfile()
        if (profile == null) {
            Toast.makeText(this, "Add a preset in QuickFill first", Toast.LENGTH_SHORT).show()
            return
        }

        val inflater = LayoutInflater.from(this)
        val panel = inflater.inflate(R.layout.overlay_panel, null)
        panelView = panel

        panel.findViewById<TextView>(R.id.textActiveProfile).text = "Active: ${profile.profileName}"

        val chipContainer = panel.findViewById<LinearLayout>(R.id.chipContainer)
        chipContainer.removeAllViews()
        val fields = profile.fieldList()
        if (fields.isEmpty()) {
            val empty = TextView(this)
            empty.text = "This preset has no fields filled in yet."
            empty.setTextColor(0xFFDDDDDD.toInt())
            chipContainer.addView(empty)
        }
        for ((label, value) in fields) {
            val chip = inflater.inflate(R.layout.item_field_chip, chipContainer, false) as TextView
            chip.text = "$label: $value"
            chip.setOnClickListener {
                val filled = AutofillAccessibilityService.instance?.fillFocusedField(value) ?: false
                Toast.makeText(
                    this,
                    if (filled) "Filled $label" else "Tap an input field first, then tap a chip",
                    Toast.LENGTH_SHORT
                ).show()
            }
            chip.setOnLongClickListener {
                val clip = ClipData.newPlainText(label, value)
                val shadow = View.DragShadowBuilder(chip)
                chip.startDragAndDrop(clip, shadow, null, View.DRAG_FLAG_GLOBAL)
                true
            }
            chipContainer.addView(chip)
        }

        panel.findViewById<Button>(R.id.btnAutofillAll).setOnClickListener {
            val count = AutofillAccessibilityService.instance?.autofillAll(profile) ?: 0
            Toast.makeText(this, "Filled $count field(s)", Toast.LENGTH_SHORT).show()
        }

        panel.findViewById<Button>(R.id.btnClosePanel).setOnClickListener { removePanel() }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams?.x ?: 0
        params.y = (bubbleParams?.y ?: 300) + 160

        windowManager.addView(panel, params)
        panelVisible = true
    }

    private fun removePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelVisible = false
    }

    companion object {
        private const val NOTIF_ID = 4201
        const val ACTION_STOP = "com.quickfill.app.ACTION_STOP"
    }
}
