package com.quickfill.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quickfill.app.data.PresetProfile
import com.quickfill.app.databinding.ItemPresetBinding

class PresetAdapter(
    private val onClick: (PresetProfile) -> Unit,
    private val onSetActive: (PresetProfile) -> Unit,
    private val onDelete: (PresetProfile) -> Unit
) : RecyclerView.Adapter<PresetAdapter.ViewHolder>() {

    private var items: List<PresetProfile> = emptyList()
    private var activeId: String? = null

    fun submitList(newItems: List<PresetProfile>, activeProfileId: String?) {
        items = newItems
        activeId = activeProfileId
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemPresetBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPresetBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val profile = items[position]
        holder.binding.textProfileName.text = profile.profileName
        val summary = listOfNotNull(
            profile.firstName.ifBlank { null },
            profile.city.ifBlank { null },
            profile.mobileNumber.ifBlank { null }
        ).joinToString("  •  ")
        holder.binding.textProfileSummary.text = summary.ifBlank { "Tap to fill in details" }
        holder.binding.iconActive.visibility =
            if (profile.id == activeId) View.VISIBLE else View.INVISIBLE

        holder.binding.root.setOnClickListener { onClick(profile) }
        holder.binding.btnSetActive.setOnClickListener { onSetActive(profile) }
        holder.binding.btnDelete.setOnClickListener { onDelete(profile) }
    }

    override fun getItemCount(): Int = items.size
}
