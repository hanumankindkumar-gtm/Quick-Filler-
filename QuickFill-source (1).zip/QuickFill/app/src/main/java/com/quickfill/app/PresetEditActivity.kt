package com.quickfill.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.quickfill.app.data.PresetProfile
import com.quickfill.app.data.PresetRepository
import com.quickfill.app.databinding.ActivityPresetEditBinding
import java.io.File
import java.io.FileOutputStream

class PresetEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPresetEditBinding
    private lateinit var repository: PresetRepository
    private var profile = PresetProfile()
    private var cameraImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { handlePickedImage(it) } }

    private val takePhotoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success -> if (success) cameraImageUri?.let { handlePickedImage(it) } }

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) launchCamera() else Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPresetEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = PresetRepository(this)

        val profileId = intent.getStringExtra(EXTRA_PROFILE_ID)
        if (profileId != null) {
            repository.getAll().find { it.id == profileId }?.let { profile = it }
            title = "Edit Preset"
        } else {
            title = "New Preset"
        }
        bindFieldsFromProfile()

        binding.btnPickImage.setOnClickListener { showImageSourceDialog() }

        binding.btnSave.setOnClickListener {
            collectFieldsIntoProfile()
            if (profile.profileName.isBlank()) {
                Toast.makeText(this, "Give this preset a name (e.g. 'Personal')", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            repository.save(profile)
            Toast.makeText(this, "Preset saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun bindFieldsFromProfile() = with(binding) {
        editProfileName.setText(profile.profileName)
        editFirstName.setText(profile.firstName)
        editMiddleName.setText(profile.middleName)
        editLastName.setText(profile.lastName)
        editAge.setText(profile.age)
        editArea.setText(profile.area)
        editPinCode.setText(profile.pinCode)
        editCity.setText(profile.city)
        editState.setText(profile.state)
        editCountry.setText(profile.country)
        editMobile.setText(profile.mobileNumber)
        editEmail.setText(profile.emailId)
        profile.idImagePath?.let { path ->
            val bmp = BitmapFactory.decodeFile(path)
            if (bmp != null) imagePreview.setImageBitmap(bmp)
        }
    }

    private fun collectFieldsIntoProfile() = with(binding) {
        profile = profile.copy(
            profileName = editProfileName.text.toString().trim(),
            firstName = editFirstName.text.toString().trim(),
            middleName = editMiddleName.text.toString().trim(),
            lastName = editLastName.text.toString().trim(),
            age = editAge.text.toString().trim(),
            area = editArea.text.toString().trim(),
            pinCode = editPinCode.text.toString().trim(),
            city = editCity.text.toString().trim(),
            state = editState.text.toString().trim(),
            country = editCountry.text.toString().trim(),
            mobileNumber = editMobile.text.toString().trim(),
            emailId = editEmail.text.toString().trim()
        )
    }

    private fun showImageSourceDialog() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        AlertDialog.Builder(this)
            .setTitle("Add ID Image")
            .setItems(options) { _, which ->
                if (which == 0) requestCameraPermission.launch(android.Manifest.permission.CAMERA)
                else pickImageLauncher.launch("image/*")
            }
            .show()
    }

    private fun launchCamera() {
        val photoFile = File(cacheDir, "id_capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
        cameraImageUri = uri
        takePhotoLauncher.launch(uri)
    }

    private fun handlePickedImage(uri: Uri) {
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: return
        val savedPath = saveBitmapToInternalStorage(bitmap)
        profile = profile.copy(idImagePath = savedPath)
        binding.imagePreview.setImageBitmap(bitmap)
    }

    private fun saveBitmapToInternalStorage(bitmap: Bitmap): String {
        val dir = File(filesDir, "id_images").apply { mkdirs() }
        val file = File(dir, "${profile.id}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        }
        return file.absolutePath
    }

    companion object {
        const val EXTRA_PROFILE_ID = "extra_profile_id"
    }
}
