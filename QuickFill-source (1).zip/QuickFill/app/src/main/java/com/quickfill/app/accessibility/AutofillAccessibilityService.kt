package com.quickfill.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.quickfill.app.data.PresetProfile

/**
 * Reads/writes the foreground app's input fields. This is what makes "autofill into any app"
 * possible at all -- it's the same mechanism password managers use.
 */
class AutofillAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We only need on-demand access to the screen tree, not continuous event streaming.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    /** Fills whichever field currently has input focus in the foreground app. */
    fun fillFocusedField(value: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return setNodeText(focused, value)
    }

    /** Best-effort: scans the foreground screen and fills fields whose label/hint/id looks like a known field. */
    fun autofillAll(profile: PresetProfile): Int {
        val root = rootInActiveWindow ?: return 0
        var filled = 0
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        collectEditableNodes(root, editableNodes)

        for (node in editableNodes) {
            val hint = listOfNotNull(
                node.hintText?.toString(),
                node.text?.toString(),
                node.contentDescription?.toString(),
                node.viewIdResourceName
            ).joinToString(" ").lowercase()

            val value = matchFieldValue(hint, profile) ?: continue
            if (setNodeText(node, value)) filled++
        }
        return filled
    }

    private fun matchFieldValue(hint: String, p: PresetProfile): String? = when {
        hint.contains("middle") -> p.middleName.ifBlank { null }
        hint.contains("first") || hint.contains("fname") || hint.contains("given") -> p.firstName.ifBlank { null }
        hint.contains("last") || hint.contains("lname") || hint.contains("surname") || hint.contains("family") -> p.lastName.ifBlank { null }
        hint.contains("age") -> p.age.ifBlank { null }
        hint.contains("pin") || hint.contains("zip") || hint.contains("postal") -> p.pinCode.ifBlank { null }
        hint.contains("area") || hint.contains("street") || hint.contains("address") || hint.contains("locality") -> p.area.ifBlank { null }
        hint.contains("city") || hint.contains("town") -> p.city.ifBlank { null }
        hint.contains("state") || hint.contains("province") -> p.state.ifBlank { null }
        hint.contains("country") -> p.country.ifBlank { null }
        hint.contains("mobile") || hint.contains("phone") || hint.contains("cell") -> p.mobileNumber.ifBlank { null }
        hint.contains("email") || hint.contains("mail") -> p.emailId.ifBlank { null }
        hint.contains("name") -> p.firstName.ifBlank { null }
        else -> null
    }

    private fun collectEditableNodes(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) {
            collectEditableNodes(node.getChild(i), out)
        }
    }

    private fun setNodeText(node: AccessibilityNodeInfo, value: String): Boolean {
        val arguments = Bundle()
        arguments.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    companion object {
        var instance: AutofillAccessibilityService? = null
            private set
    }
}
