package com.quickfill.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.quickfill.app.data.PresetRepository
import com.quickfill.app.databinding.ActivityMainBinding
import com.quickfill.app.overlay.OverlayService
import com.quickfill.app.utils.PermissionUtils

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: PresetRepository
    private lateinit var adapter: PresetAdapter

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        repository = PresetRepository(this)

        adapter = PresetAdapter(
            onClick = { profile ->
                startActivity(Intent(this, PresetEditActivity::class.java)
                    .putExtra(PresetEditActivity.EXTRA_PROFILE_ID, profile.id))
            },
            onSetActive = { profile ->
                repository.setActiveProfileId(profile.id)
                refreshList()
                Toast.makeText(this, "${profile.profileName} set as active", Toast.LENGTH_SHORT).show()
            },
            onDelete = { profile ->
                repository.delete(profile.id)
                refreshList()
            }
        )
        binding.recyclerPresets.layoutManager = LinearLayoutManager(this)
        binding.recyclerPresets.adapter = adapter

        binding.fabAddPreset.setOnClickListener {
            startActivity(Intent(this, PresetEditActivity::class.java))
        }

        binding.btnOverlayPermission.setOnClickListener {
            startActivity(PermissionUtils.overlayPermissionIntent(this))
        }

        binding.btnAccessibilityPermission.setOnClickListener {
            startActivity(PermissionUtils.accessibilitySettingsIntent())
        }

        binding.btnStartBubble.setOnClickListener {
            if (!PermissionUtils.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant the overlay permission first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!PermissionUtils.isAccessibilityServiceEnabled(this)) {
                Toast.makeText(this, "Enable the QuickFill accessibility service first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (repository.getActiveProfile() == null) {
                Toast.makeText(this, "Add a preset first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Floating bubble started — switch to any app", Toast.LENGTH_SHORT).show()
        }

        binding.btnStopBubble.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        updatePermissionStatus()
    }

    private fun refreshList() {
        val list = repository.getAll()
        adapter.submitList(list, repository.getActiveProfileId())
        binding.emptyState.visibility =
            if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun updatePermissionStatus() {
        binding.btnOverlayPermission.text = if (PermissionUtils.canDrawOverlays(this))
            "✓ Overlay permission granted" else "1. Grant overlay permission"
        binding.btnAccessibilityPermission.text = if (PermissionUtils.isAccessibilityServiceEnabled(this))
            "✓ Accessibility service enabled" else "2. Enable accessibility service"
    }
}
