package com.quickfill.app.data

import android.content.Context
import org.json.JSONArray

class PresetRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("quickfill_presets", Context.MODE_PRIVATE)

    fun getAll(): MutableList<PresetProfile> {
        val raw = prefs.getString(KEY_PRESETS, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val list = mutableListOf<PresetProfile>()
        for (i in 0 until arr.length()) {
            list.add(PresetProfile.fromJson(arr.getJSONObject(i)))
        }
        return list
    }

    fun save(profile: PresetProfile) {
        val list = getAll()
        val index = list.indexOfFirst { it.id == profile.id }
        if (index >= 0) list[index] = profile else list.add(profile)
        persist(list)
        if (getActiveProfileId() == null) setActiveProfileId(profile.id)
    }

    fun delete(profileId: String) {
        val list = getAll().filterNot { it.id == profileId }.toMutableList()
        persist(list)
        if (getActiveProfileId() == profileId) {
            setActiveProfileId(list.firstOrNull()?.id)
        }
    }

    fun getActiveProfile(): PresetProfile? {
        val activeId = getActiveProfileId() ?: return getAll().firstOrNull()
        return getAll().find { it.id == activeId } ?: getAll().firstOrNull()
    }

    fun getActiveProfileId(): String? = prefs.getString(KEY_ACTIVE_ID, null)

    fun setActiveProfileId(id: String?) {
        prefs.edit().putString(KEY_ACTIVE_ID, id).apply()
    }

    private fun persist(list: List<PresetProfile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_PRESETS, arr.toString()).apply()
    }

    companion object {
        private const val KEY_PRESETS = "presets_json"
        private const val KEY_ACTIVE_ID = "active_profile_id"
    }
}
