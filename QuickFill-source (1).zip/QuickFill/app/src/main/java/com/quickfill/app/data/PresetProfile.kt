package com.quickfill.app.data

import org.json.JSONObject
import java.util.UUID

data class PresetProfile(
    val id: String = UUID.randomUUID().toString(),
    var profileName: String = "My Info",
    var firstName: String = "",
    var middleName: String = "",
    var lastName: String = "",
    var age: String = "",
    var area: String = "",
    var pinCode: String = "",
    var city: String = "",
    var state: String = "",
    var country: String = "",
    var mobileNumber: String = "",
    var emailId: String = "",
    var idImagePath: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("profileName", profileName)
        put("firstName", firstName)
        put("middleName", middleName)
        put("lastName", lastName)
        put("age", age)
        put("area", area)
        put("pinCode", pinCode)
        put("city", city)
        put("state", state)
        put("country", country)
        put("mobileNumber", mobileNumber)
        put("emailId", emailId)
        put("idImagePath", idImagePath ?: "")
    }

    /** Ordered (label, value) pairs for non-blank fields, used to render chips on the bubble. */
    fun fieldList(): List<Pair<String, String>> = listOf(
        "First Name" to firstName,
        "Middle Name" to middleName,
        "Last Name" to lastName,
        "Age" to age,
        "Area" to area,
        "Pin Code" to pinCode,
        "City" to city,
        "State" to state,
        "Country" to country,
        "Mobile Number" to mobileNumber,
        "Email ID" to emailId
    ).filter { it.second.isNotBlank() }

    companion object {
        fun fromJson(obj: JSONObject): PresetProfile = PresetProfile(
            id = obj.optString("id", UUID.randomUUID().toString()),
            profileName = obj.optString("profileName", "My Info"),
            firstName = obj.optString("firstName", ""),
            middleName = obj.optString("middleName", ""),
            lastName = obj.optString("lastName", ""),
            age = obj.optString("age", ""),
            area = obj.optString("area", ""),
            pinCode = obj.optString("pinCode", ""),
            city = obj.optString("city", ""),
            state = obj.optString("state", ""),
            country = obj.optString("country", ""),
            mobileNumber = obj.optString("mobileNumber", ""),
            emailId = obj.optString("emailId", ""),
            idImagePath = obj.optString("idImagePath", "").ifBlank { null }
        )
    }
}
