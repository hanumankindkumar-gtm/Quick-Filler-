# QuickFill — setup guide

A floating bubble that holds your saved presets (name, address, contact info, ID photo) and
autofills them into whatever app is currently open, using an Accessibility Service.

## Option A — Get an APK without installing anything (recommended)

This project already includes everything needed for GitHub to build the APK for you for free.

### If you're on a phone (no folder upload needed)
Phone file pickers usually can't select a whole folder, so do it as two single-file steps instead:

1. On github.com (mobile browser), sign in and create a **new repository** (any name).
2. Tap **Add file → Create new file**. For the filename, type the *full path*:
   `.github/workflows/build-apk.yml` — GitHub will auto-create the folders. Open
   `build-apk.yml` from inside the unzipped project on your phone (or open the zip with
   a file manager app first), copy its contents, paste them in, and commit.
3. Tap **Add file → Upload files**, and this time upload just the single
   `QuickFill-source.zip` file (don't unzip it) to the repo root. Commit.
4. Go to the **Actions** tab — a build should already be running. Wait ~3–5 minutes.
5. Open the finished run → **Artifacts** → download **QuickFill-debug-apk** → unzip it →
   you get `app-debug.apk`.
6. Open that file on your phone to install it (allow "install from unknown sources" when asked).

### If you're on a computer
1. Create a new repo on github.com.
2. **Add file → Upload files**, then drag in the entire unzipped `QuickFill` folder
   (keeping its structure intact) and commit.
3. Same as above from the Actions tab onward.

## Option B — Build it yourself in Android Studio

If you'd rather build locally (e.g. to debug, or run straight to a USB-connected phone):

### 1. Create the project
Android Studio → New Project → **Empty Views Activity** → Language: **Kotlin**
- Package name: `com.quickfill.app` (use this exact name so it matches the files below)
- Minimum SDK: **API 26 (Android 8.0)**

## 2. Drop in the files
Replace/add these into your new project, keeping the same folder structure:

- `app/src/main/AndroidManifest.xml` → replace
- `app/src/main/java/com/quickfill/app/MainActivity.kt` → replace
- `app/src/main/java/com/quickfill/app/PresetAdapter.kt` → add
- `app/src/main/java/com/quickfill/app/PresetEditActivity.kt` → add
- `app/src/main/java/com/quickfill/app/data/PresetProfile.kt` → add (new `data` folder)
- `app/src/main/java/com/quickfill/app/data/PresetRepository.kt` → add
- `app/src/main/java/com/quickfill/app/overlay/OverlayService.kt` → add (new `overlay` folder)
- `app/src/main/java/com/quickfill/app/accessibility/AutofillAccessibilityService.kt` → add (new `accessibility` folder)
- `app/src/main/java/com/quickfill/app/utils/PermissionUtils.kt` → add (new `utils` folder)
- All files under `res/layout/`, `res/drawable/` (including `ic_launcher_quickfill.xml`), `res/xml/` → add
- `res/values/strings.xml` and `res/values/themes.xml` → replace the generated ones

### 3. Update app/build.gradle.kts (Module :app)
Inside `android { }` add:
```kotlin
buildFeatures {
    viewBinding = true
}
```
Inside `dependencies { }` add (skip any that are already there):
```kotlin
implementation("androidx.recyclerview:recyclerview:1.3.2")
implementation("androidx.cardview:cardview:1.0.0")
implementation("androidx.activity:activity-ktx:1.9.0")
implementation("com.google.android.material:material:1.12.0")
```
(Using Groovy `build.gradle` instead? Same lines without parentheses, e.g.
`implementation 'androidx.recyclerview:recyclerview:1.3.2'`.)

Then **Sync Gradle** and **Build → Make Project**.

### 4. Run it
1. Install on a real device (overlay + accessibility behave more reliably than on an emulator).
2. Open QuickFill, tap **+**, fill in a preset (name, address, mobile, email, ID photo), save it.
3. Tap **"1. Grant overlay permission"** → allow it.
4. Tap **"2. Enable accessibility service"** → find QuickFill in the list → turn it on.
5. Tap **Start bubble**. A small 😎 bubble appears, draggable anywhere on screen.
6. Open any other app, tap into a text field, then tap the bubble → tap a chip (e.g. "Email ID") → it fills that field.
7. Or long-press a chip and drag it directly onto a visible field.
8. **"⚡ Autofill all matching fields"** tries to fill every recognizable field on screen at once (matches by hint/label text — e.g. fields containing "city", "email", "pin"/"zip", etc.).

## Good to know
- **Tap-to-fill is the reliable method** — it works on virtually any standard Android input field.
  **Drag-and-drop** only works when the target field is a normal `EditText`-based view; some apps
  built with Flutter, React Native, or custom-rendered text fields won't accept a drop, so tap-to-fill
  is the fallback that always works there.
- Secure fields (e.g. bank app passwords) intentionally block accessibility read/write — that's the OS protecting you, not a bug.
- Everything (presets + the ID photo) is stored only on-device in app-private storage — nothing is uploaded anywhere, and the app requests no internet permission.
- If you ever want to publish this to the Play Store, be aware Google reviews accessibility-service apps strictly for this kind of "fill other apps' fields" use case — fine for personal/sideloaded use, but plan for that review if you go that route.
